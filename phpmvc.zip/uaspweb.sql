-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2021 at 04:27 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uaspweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `topic` varchar(20) NOT NULL,
  `video` varchar(50) NOT NULL,
  `images` varchar(255) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `name`, `title`, `subtitle`, `topic`, `video`, `images`, `description`) VALUES
(1, 'John Doe', 'Jaga Kesehatan', 'Incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate. ', 'Kesehatan', 'https://www.youtube.com/embed/1z--ZRS5x5U', 'C:/xampp/htdocs/phpmvc/public/uploads/3_1.png', 'Incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate. Incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate. Incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate. '),
(2, 'Joko ', 'Makanan Bergizi Bantu Tumbuh Kembang', 'Berikut tips yang bisa anda terapkan untuk memperbaiki gizi buruk yang terjadi pada keluarga atau teman anda.', 'Jasmani', 'https://www.youtube.com/embed/clU8c2fpk2s', 'C:/xampp/htdocs/phpmvc/public/uploads/EDIT.jpg', '\r\n    Media Contact\r\n    Mr. John Doe\r\n    010-020-0340\r\n\r\n    Technical Contact\r\n    Mr. John Stiles\r\n    010-020-0340\r\n\r\n    Billing Contact\r\n    Mr. Richard Miles\r\n    010-020-0340\r\n\r\n'),
(3, 'Hendra Sunjoto', 'Minum Degan Bermanfaat', 'Minuman segar yang mudah didapat ini ternyata memiliki khasiat', 'Kebugaran', 'https://www.youtube.com/embed/clU8c2fpk2s', 'C:/xampp/htdocs/phpmvc/public/uploads/WhatsApp_Image_2020-05-02_at_18-removebg-preview.png', 'isi kontent'),
(4, 'Rafles Arnold', 'Telur mengandung kolesterol', 'setiap hari kita mengkonsumsi makanan penuh kolesterol', 'Kesehatan', 'https://www.youtube.com/embed/clU8c2fpk2s', 'C:/xampp/htdocs/phpmvc/public/uploads/WhatsApp_Image_2020-05-02_at_18-removebg-preview (2).png', '## Cara Mencegah Tinggi Kolesterol\r\n1.	Kurangi makan telur\r\n2.	Perbanyak olahraga\r\n3.	Hindari makanan instan\r\n\r\n> Yang terpenting anda harus hemat\r\n> \r\n![enter image description here](https://eusipco2012.org/wp-content/uploads/2020/11/health-insurance-getty-imag.jpg)\r\n - [ ] Tidur Tepat Waktu\r\n\r\nBaca *referensi* di link [berikut](www.google.com)'),
(5, 'Prabowo Subianto', 'Belajar Hidup Sehat', 'Berikut tips yang bisa anda terapkan untuk memperbaiki gizi buruk yang terjadi pada keluarga atau teman anda.', 'Kesehatan', 'https://www.youtube.com/embed/clU8c2fpk2s', 'C:/xampp/htdocs/phpmvc/public/uploads/aaron-lee-Z9OTfVyeaTQ-unsplash.jpg', '## Cara Belajar Coding');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `id_article` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `currentdate` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `id_article`, `name`, `email`, `description`, `currentdate`) VALUES
(2, 1, 'masnopalz', 'masnopalz@gmail.com', 'keren kak', '26 May 2021'),
(3, 2, 'Rizal', 'Rizal@yahoo.com', 'lumayan', '26 May 2021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
